#!/usr/bin/env python3
# coding=utf-8

import rospy  # type: ignore
import numpy as np # type: ignore
from sensor_msgs.msg import LaserScan # type: ignore
from sklearn.cluster import DBSCAN # type: ignore
from geometry_msgs.msg import Twist,PoseStamped # type: ignore
from std_msgs.msg import Int32,Int8,Float64 # type: ignore
from sensor_msgs.msg import Imu # type: ignore
from tf.transformations import euler_from_quaternion # type: ignore
import math
import time
from math import factorial
import subprocess
import tf
from scipy.spatial import KDTree
from scipy.interpolate import splprep, splev
import csv, codecs
from nav_msgs.msg import Path,Odometry
import os
from collections import deque
def execute_ros_command(command):
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()

################ 閲嶈 佸弬鏁  ################
bend_kp=1
bend_ki=0
bend_kd=0

SPEED=1560    # 涓婚€熷害
SPEED_STRAIGHT=1570   # 鐩撮亾閫熷害
SPEED_NAV=1570
K_E = 1.1
FOLLOW = 50
################ 閲嶈 佸弬鏁  ################

# 妯″紡鍒囨崲鏍囧織浣 
# flag = 0 鎽勫儚澶磋  绾 
# flag = 1 闆疯揪宸＄嚎
# flag = 2 绾㈢豢鐏 鍋滆溅3s
# flag = 3 鐩撮亾鍔犻€ 
# flag = 4 闆疯揪宸＄嚎
# flag = 6 绾㈢豢鐏 鍋滆溅3s
# flag = 7 A鐐瑰仠杞 
# flag = 8 缁撴潫
flag = 0

################ 鍙 璋冩暣鍙傛暟 ################
# 璁剧疆婵€鍏夐浄杈剧殑鏈€澶ф €娴嬭窛绂伙紙浠ョ背涓哄崟浣嶏級
max_distance = 3 # 鍙 鑱氱被绂婚浄杈 3绫充互鍐呯殑鐐 

# 璁剧疆鍓嶆柟鐨勮 掑害鑼冨洿锛堜互寮у害涓哄崟浣嶏級
front_angle_min = -95* np.pi / 180  # 杞﹁韩鍓嶆柟鏈€灏忚 掑害锛 -95搴︼級
front_angle_max = 95 * np.pi / 180   # 杞﹁韩鍓嶆柟鏈€澶ц 掑害锛 95搴︼級

# 璁剧疆DBSCAN鑱氱被鐨勫弬鏁 
dbscan_eps = 0.14  # 閭诲煙鍗婂緞
dbscan_min_samples = 7  # 姣忎釜绨囩殑鏈€灏忔牱鏈 鏁 
################ 鍙 璋冩暣鍙傛暟 ################

################ 鍙橀噺鍒濆 嬪寲 ################
encoder_start_flag=0
# 璺濈 诲垵濮嬬偣鐨勭紪鐮佸櫒璺濈  
distance_to_start=0
cur_vel = 0
# 寮у害鎹㈢畻鎴愯 掑害
roll  =0
pitch =0
yaw   =0
# 璁剧疆鍚 鍔ㄦ椂鐨勮埅鍚戣 掍负0搴 
zero_yaw=0
# 鐩稿 逛簬璧峰 嬬偣锛 0锛 0锛夛紝杞︾殑浜岀淮鍧愭爣锛坸锛寉锛 
x = 0
y = 0
theta = 0
#闆疯揪鎵 绾 
mid_x=[]
mid_y=[]
delta_degrees=0
delta_degrees1=0
error=0
################ 鍙橀噺鍒濆 嬪寲 ################

kp = 1.05
ki = 0
kd = 0
change_receive = 0
cur_vel = 0
stop_point = 0
save_flag=0
class PID:
    def __init__(self, kp, ki, kd, integral_limit=8.0):
        """
        鍒濆 嬪寲PID鎺у埗鍣ㄣ€ 
        kp, ki, kd 鏄疨ID鍙傛暟銆 
        integral_limit 鏄 绉 鍒嗛」鐨勯檺鍒讹紝浠ラ槻姝㈢Н鍒嗗€艰繃澶с€ 
        """
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral_limit = integral_limit
        self.error_out = 0.0
        self.last_error = 0.0
        self.integral = 0.0
        self.last_diff = 0.0


    def positional(self, error):
        """
        浣嶇疆寮廝ID鎺у埗鍣ㄣ€ 
        鏍规嵁璇 宸 璁＄畻鎺у埗杈撳嚭銆 
        """
        self.integral += error
        # 绉 鍒嗛檺骞 
        if self.integral > self.integral_limit:
            self.integral = self.integral_limit

        self.error_out = (self.kp * error) + (self.ki * self.integral) + (self.kd * (error - self.last_error))
        self.last_error = error
        return self.error_out

    def incremental(self, error):
        """
        澧為噺寮廝ID鎺у埗鍣ㄣ€ 
        鏍规嵁璇 宸 璁＄畻鎺у埗杈撳嚭銆 
        """
        self.error_out = self.kp * (error - self.last_error) + self.ki * error + self.kd * ((error - self.last_error) - self.last_diff)
        self.last_diff = error - self.last_error
        self.last_error = error
        return self.error_out



class StanleyController:
    def __init__(self, k_e=1, wheel_base=1.0, lookahead_points=7):
        self.k_e = k_e
        self.wheel_base = wheel_base
        self.tf_listener = tf.TransformListener()
        self.rate = rospy.Rate(10)
        self.lookahead_points = lookahead_points  # 瀹氫箟瑕佹煡鐪嬬殑璺 寰勭偣鏁伴噺
        self.path = None
        self.last_index = 0
        self.current_pose = PoseStamped()
        rospy.Subscriber('/encoder_imu_odom', Odometry, self.odom_callback)

    def odom_callback(self, msg):
        self.current_pose.pose.position.x = msg.pose.pose.position.x
        self.current_pose.pose.position.y = msg.pose.pose.position.y
        self.current_pose.pose.orientation = msg.pose.pose.orientation


    def set_path(self, path):
        """璁剧疆璺 寰 """
        self.path = path

    def calculate_control(self, current_pose):
        """璁＄畻Stanley鎺у埗鎸囦护"""
        nearest_index, nearest_distance = self.get_nearest_point(current_pose)

        # 璁＄畻妯 鍚戣  宸 锛坈ross-track error锛 
        # 璁＄畻璺 寰勬柟鍚戝悜閲 
        dx = self.path[min(nearest_index+2,len(self.path))-1][0] - self.path[nearest_index][0]
        dy = self.path[min(nearest_index+2,len(self.path))-1][1] - self.path[nearest_index][1]

        # 璁＄畻杞﹁締褰撳墠浣嶇疆涓庤矾寰勬渶杩戠偣涔嬮棿鐨勫悜閲 
        ex = current_pose.pose.position.x - self.path[nearest_index][0]
        ey = current_pose.pose.position.y - self.path[nearest_index][1]

        # 璁＄畻鍙夌Н鏉ュ垽鏂 宸﹀彸鏂瑰悜
        cross_product = dx * ey - dy * ex

        # 鏍规嵁鍙夌Н涓烘í鍚戣  宸 璧嬩簣姝ｈ礋鍙 
        if cross_product < 0:
            e = nearest_distance  # 鍦ㄨ矾寰勫乏渚 
        else:
            e = -nearest_distance  # 鍦ㄨ矾寰勫彸渚 


        # 璁＄畻鑸 鍚戣  宸 锛坔eading error锛 
        # 浣跨敤鍚庨潰鍑犱釜鐐规潵璁＄畻璺 寰勭殑鐩 鏍囨柟鍚 
        if nearest_index + self.lookahead_points < len(self.path):
            target_index = nearest_index + self.lookahead_points
        else:
            target_index = len(self.path) - 1
            rospy.loginfo("arrived!!")
            pub_flag =rospy.Publisher('/change', Int8, queue_size=10)
            pub_flag.publish(5)
            
        #rospy.loginfo("褰撳墠杩涘害锛 %2f/%2f.",target_index,len(self.path))
        yaw_path = self.get_yaw_from_path(nearest_index, target_index)
        yaw_current = self.get_yaw(current_pose.pose.orientation)
        theta_e = self.normalize_angle(yaw_path - yaw_current)

        # Stanley鎺у埗寰 
        v = cur_vel  
        if v == 0:
            v = 1
        #v = 1   # 鍋囪 鹃€熷害鎭掑畾涓  ~ m/s
        heng_e = np.arctan2(self.k_e * e, v)#v瓒婂皬锛岃 掕秺澶э紱k_e瓒婂ぇ锛岃 掕秺澶 
        delta = theta_e + heng_e
        
        # 灏哾elta杞 鎹 涓鸿 掑害鍒讹紙搴︼級
        delta_degrees = np.degrees(delta)
        theta_e_degrees = np.degrees(theta_e)
        heng_e_degrees = np.degrees(heng_e)
        rospy.loginfo("theta_e is :%2f", theta_e_degrees)
        rospy.loginfo("heng_e is :%2f", heng_e_degrees)
        return delta_degrees

    def control_loop(self):
        global flag,delta_degrees1,x_laser
        if flag == 4 or flag== 5:
            # 璁＄畻鎺у埗鎸囦护
            delta = self.calculate_control(self.current_pose)
            if flag==4:
                self.publish_control(delta)
            if flag==5:
                self.publish_control(delta*0.85+delta_degrees1*0.15)
            self.rate.sleep()


    def publish_control(self, delta):
        """鍙戝竷鎺у埗鎸囦护"""
        global vel_pub,SPEED_NAV
        cmd = Twist()
        cmd.linear.x = SPEED_NAV  # 鎭掑畾閫熷害
        angular_z = 80 + delta
        if angular_z <=0:
            angular_z = 0
        if angular_z >= 180:
            angular_z = 180
        cmd.angular.z = angular_z
        
        vel_pub.publish(cmd)

    def get_nearest_point(self, current_pose):
        """鎵惧埌涓庡綋鍓嶈溅杈嗕綅缃 鏈€杩戠殑璺 寰勭偣"""
        min_dist = float('inf')
        min_index = self.last_index  # 浠庝笂涓€娆℃壘鍒扮殑鐐瑰紑濮嬫悳绱 
        search_range = 20  # 璁剧疆鎼滅储鑼冨洿锛岄伩鍏嶉亶鍘嗘暣涓 璺 寰 
        for i in range(max(self.last_index-search_range,0), min(self.last_index + search_range, len(self.path))):
            point = self.path[i]
            dist = np.sqrt((point[0] - current_pose.pose.position.x)**2 +
                        (point[1] - current_pose.pose.position.y)**2)
            if dist < min_dist:
                min_dist = dist
                min_index = i
                if min_dist < 0.05:  # 濡傛灉璺濈 诲皬浜庢煇涓 闃堝€硷紝鍒欒 や负鎵惧埌浜嗘渶杩戠偣
                    #rospy.loginfo("鏈€杩戠偣鐨剎:%.2f,y:%.2f,搴忓彿:%2f銆 ", point[0], point[1],i)
                    break
        rospy.loginfo("鎵惧埌鐨勬渶杩戠偣鍧愭爣:%2f,%2f.",self.path[self.last_index][0],self.path[self.last_index][1])
        self.last_index = min_index  # 璁板綍褰撳墠鎵惧埌鐨勬渶杩戠偣鐨勭储寮 
        rospy.loginfo("褰撳墠鐐 :x:%.2f,y:%.2f銆 ", current_pose.pose.position.x, current_pose.pose.position.y)
        #rospy.loginfo("鏈€杩戠偣鐨勮窛绂伙細%.2f,瑙掑害锛 %.2f銆 ", min_dist, min_index) 
        return min_index, min_dist

    def get_yaw_from_path(self, start_index, target_index):
        """浠庤矾寰勬 典腑鑾峰彇鐩 鏍囨柟鍚戠殑yaw"""
        dx = self.path[target_index][0] - self.path[start_index][0]
        dy = self.path[target_index][1] - self.path[start_index][1]
        return np.arctan2(dy, dx)

    def get_yaw(self, orientation):
        """浠庡洓鍏冩暟涓 鑾峰彇yaw锛堣埅鍚戣 掞級"""
        quaternion = (orientation.x, orientation.y, orientation.z, orientation.w)
        euler = tf.transformations.euler_from_quaternion(quaternion)
        return euler[2]

    def quaternion_to_orientation(self, quaternion):
        """灏嗗洓鍏冩暟杞 鎹 涓篟OS涓 鐨凮rientation绫诲瀷"""
        orientation = PoseStamped().pose.orientation
        orientation.x = quaternion[0]
        orientation.y = quaternion[1]
        orientation.z = quaternion[2]
        orientation.w = quaternion[3]
        return orientation

    def normalize_angle(self, angle):
        """灏嗚 掑害褰掍竴鍖栧埌[-蟺, 蟺]鑼冨洿"""
        if angle > np.pi:
            angle -= 2.0 * np.pi
        elif angle < -np.pi:
            angle += 2.0 * np.pi
        return angle

def read_points_from_csv(file_name):
    """浠嶤SV鏂囦欢涓 璇诲彇鐐逛綅鏁版嵁"""
    points = []
    base_path = Path()
    base_path.header.frame_id = 'odom'
    pub_path = rospy.Publisher('/base_path', Path, queue_size=1, latch=True)
    with open(file_name, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            x, y, z, w = map(float, row)
            points.append([x, y, z, w])
            path_element = PoseStamped()
            path_element.pose.position.x = x
            path_element.pose.position.y = y
            base_path.poses.append(path_element)
        pub_path.publish(base_path)
        rospy.loginfo("updated!")
        
    return points

def bezier_curve_fitting(points, num_points=100):
    """鍩轰簬鎺у埗鐐硅繘琛岃礉濉炲皵鏇茬嚎鎷熷悎锛岀敓鎴愯矾寰 """
    points = np.array(points)
    tck, u = splprep([points[:, 0], points[:, 1]], s=0)
    u_new = np.linspace(u.min(), u.max(), num_points)
    x_new, y_new = splev(u_new, tck, der=0)
    return x_new, y_new

def velocityCallback(vel_msg):
    global cur_vel
    cur_vel = vel_msg.data

# 缂栫爜鍣ㄧ被
class EncoderDistanceTracker:
    def __init__(self):
        self.start_distance = 0
        self.current_distance = 0

    def start_recording(self, current_encoder_value):
        """寮€濮嬭 板綍绉 鍒嗭紝涓嶈繑鍥炲€ """
        self.start_distance = current_encoder_value

    def get_current_distance(self, current_encoder_value):
        """鑾峰彇褰撳墠鐨勭Н鍒嗚窛绂 """
        self.current_distance = current_encoder_value - self.start_distance
        return self.current_distance


# class LaserScanPublisher:
#     def __init__(self):
#         # 鍒濆 嬪寲鑺傜偣
#         rospy.init_node('laser_scan_publisher')

#         # 璁剧疆闃熷垪澶у皬
#         self.queue = deque(maxlen=1)  # 淇濈暀鏈€鏂扮殑婵€鍏夐浄杈炬暟鎹 

#         # 璁㈤槄闆疯揪淇℃伅璇濋 樺拰鏍囧織璇濋  
#         self.laser_sub = rospy.Subscriber('/scan', LaserScan, self.laser_callback, queue_size=10)
        
#         # 鍙戝竷鏈€鏂伴浄杈炬暟鎹 鐨勮瘽棰 
#         self.pub = rospy.Publisher('/latest_laser_scan', LaserScan, queue_size=10)

#         self.flag = flag  # 鍒濆 嬫爣蹇椾负False

#     def laser_callback(self, msg):
#         # 鏇存柊闆疯揪鏁版嵁闃熷垪
#         self.queue.append(msg)

#     def flag_callback(self, msg):
#         # 鏇存柊鏍囧織
#         self.flag = msg.data

#         # 濡傛灉鏍囧織涓篢rue锛屽彂甯冩渶鏂扮殑闆疯揪鏁版嵁
#         if self.flag==1 and self.queue:
#             latest_scan = self.queue[-1]  # 鑾峰彇闃熷垪涓 鏈€鏂扮殑闆疯揪鏁版嵁
#             self.pub.publish(latest_scan)




# PID绫 
class PID:
    def __init__(self, kp, ki, kd, integral_limit=8.0):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral_limit = integral_limit
        self.error_out = 0.0
        self.last_error = 0.0
        self.integral = 0.0
        self.last_diff = 0.0

    def positional(self, error):
        self.integral += error
        # 绉 鍒嗛檺骞 
        if self.integral > self.integral_limit:
            self.integral = self.integral_limit

        self.error_out = (self.kp * error) + (self.ki * self.integral) + (self.kd * (error - self.last_error))
        self.last_error = error
        return self.error_out

    def incremental(self, error):
        self.error_out = self.kp * (error - self.last_error) + self.ki * error + self.kd * ((error - self.last_error) - self.last_diff)
        self.last_diff = error - self.last_error
        self.last_error = error
        return self.error_out

################ 涓昏 佺畻娉  ################
#璇嗗埆閿ユ《鐨勭畻娉曞嚱鏁 
def allocate_cones(cones):
    """
    灏嗛敟妗跺垎閰嶅埌宸﹀彸鏁扮粍涓 銆 

    鍙傛暟:
    cones (list): 閿ユ《鐨勪簩缁村潗鏍囧垪琛 

    杩斿洖:
    tuple: 宸︿晶閿ユ《鍒楄〃鍜屽彸渚ч敟妗跺垪琛 
    """
    cone1=cones[0].copy()
    cone2=cones[0].copy()
    cone1[0]=-0.1
    cone1[1]=0.7
    left_cones = [cone1] 
    cone2[0]=-0.1
    cone2[1]=-0.7
    right_cones = [cone2]

    # 鑾峰彇鍓╀綑閿ユ《
    remaining_cones = set(range(len(cones))) - {i for i, cone in enumerate(cones) if np.array_equal(cone, left_cones[0]) or np.array_equal(cone, right_cones[0])}

    # 鎵惧埌鍓╀綑閿ユ《
    for _ in range(5):
        if remaining_cones:
            # 鎵惧埌绂诲乏渚ч敟妗舵渶杩戠殑閿ユ《
            left_distances = np.array([np.linalg.norm(cones[i] - left_cones[-1]) for i in remaining_cones])
            left_nearest_idx = list(remaining_cones)[np.argmin(left_distances)]
            if np.linalg.norm(left_cones[len(left_cones)-1]-cones[left_nearest_idx])<=1.2:
                left_cones.append(cones[left_nearest_idx])
                remaining_cones.remove(left_nearest_idx)

        if remaining_cones:
            # 鎵惧埌绂诲彸渚ч敟妗舵渶杩戠殑閿ユ《
            right_distances = np.array([np.linalg.norm(cones[i] - right_cones[-1]) for i in remaining_cones])
            right_nearest_idx = list(remaining_cones)[np.argmin(right_distances)]
            if np.linalg.norm(right_cones[len(right_cones)-1]-cones[right_nearest_idx])<=1.35:
                right_cones.append(cones[right_nearest_idx])
                remaining_cones.remove(right_nearest_idx)
    return left_cones, right_cones

#鎸囨暟鍔犳潈绠楁硶 瀵规渶鏂版暟鎹 鍙樺寲鍝嶅簲杈冨揩锛屽悓鏃朵繚鐣欏巻鍙叉暟鎹 
def ewma(values, alpha):
    weighted_sum = 0
    weighted_values = []
    for i, v in enumerate(values):
        weighted_sum = alpha * v + (1 - alpha) * weighted_sum
        weighted_values.append(weighted_sum)
    return weighted_values[-1]

#璐濆 炲皵鏇茬嚎鎷熷悎鍑芥暟璋冪敤
def binom(n, k):
    return factorial(n) // (factorial(k) * factorial(n - k))

#鐢熸垚璐濆 炲皵鏇茬嚎
def bezier_curve(points, n_points=100):
    n = len(points) - 1
    t = np.linspace(0, 1, n_points)
    curve = np.zeros((n_points, 2))
    for i in range(n_points):
        for j in range(n + 1):
            # 鎵嬪姩璁＄畻缁勫悎鏁 
            binom_coeff = binom(n, j)
            
            # 璁＄畻璐濆 炲皵鍩哄嚱鏁扮殑鍊 
            basis = (t[i] ** j) * ((1 - t[i]) ** (n - j))
            
            # 鍙犲姞姣忎釜鎺у埗鐐瑰 瑰綋鍓嶆洸绾夸笂鐐圭殑璐＄尞
            curve[i] += binom_coeff * basis * points[j]
    return curve[:, 0], curve[:, 1]

#宸﹀彸杈圭嚎鎷熷悎鍑轰腑绾 
def midpoints_curve(left_curve, right_curve):
    mid_x = (left_curve[0] + right_curve[0]) / 2
    mid_y = (left_curve[1] + right_curve[1]) / 2
    return mid_x, mid_y

def get_yaw_from_path(x,y):
    dx = x[50] - x[30]
    dy = y[50] - y[30]
    return np.arctan2(dy, dx)

def normalize_angle(angle):
    """灏嗚 掑害褰掍竴鍖栧埌[-蟺, 蟺]鑼冨洿"""
    if angle > np.pi:
        angle -= 2.0 * np.pi
    elif angle < -np.pi:
        angle += 2.0 * np.pi
    return angle
################ 涓昏 佺畻娉  ################

################ 鍥炶皟鍑芥暟 ################
#鏍囧織浣嶈浆鎹㈠洖璋冨嚱鏁 
def change_callback(msg):
    global change_receive
    change_receive = msg.data

################ 璁扮偣鍑芥暟 ################
recording_distance = 0.4  # 璁剧疆璁板綍鐐圭殑璺濈 婚槇鍊硷紝鍗曚綅涓虹背
last_recorded_position = None  # 鐢ㄤ簬瀛樺偍涓婁竴涓 璁板綍鐐圭殑浣嶇疆
point = []
#laser_go   flag
flag_last = 0

def convert_to_pose_stamped(data):
    pose_stamped = PoseStamped()
    pose_stamped.header = data.header  # 淇濈暀鏃堕棿鎴冲拰frame_id
    pose_stamped.pose = data.pose.pose  # 鐩存帴鎻愬彇浣嶅Э
    return pose_stamped

def odom_callback(self, msg):
    self.current_pose.pose.position.x = msg.pose.pose.position.x
    self.current_pose.pose.position.y = msg.pose.pose.position.y
    self.current_pose.pose.orientation = msg.pose.pose.orientation
    
def distance_between_points(p1, p2):
    """璁＄畻涓ょ偣涔嬮棿鐨勬 у嚑閲屽緱璺濈  """
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

x_laser=0

#杞︾浉瀵逛簬璧峰 嬬偣鐨勫潗鏍囧拰鑸 鍚戣 掑洖璋冨嚱鏁 
def odom_callback(odom_msg):
    global flag,x,y,theta,x_laser,save_flag
    global last_recorded_position, point,flag_last
    x = odom_msg.pose.pose.position.x
    x_laser=x
    y = odom_msg.pose.pose.position.y
    theta = odom_msg.pose.pose.orientation.z

    # 浣跨敤 Odometry 娑堟伅涓 鐨  pose 鏁版嵁
    if save_flag==0:
        current_position = (odom_msg.pose.pose.position.x, odom_msg.pose.pose.position.y)
        if flag ==2 and flag_last == 0:
            flag_last = 1
            point.append([current_position[0], current_position[1]])

        if last_recorded_position is None:
            point.append([current_position[0], current_position[1]])
            last_recorded_position = current_position
        else:
            distance = distance_between_points(current_position, last_recorded_position)
            if distance >= recording_distance:
                point.append([current_position[0], current_position[1]])
                last_recorded_position = current_position
                rospy.loginfo("璁板綍鏂扮偣: %2f, %2f", current_position[0], current_position[1])

def data_write_csv(file_name, datas):
    file_csv = codecs.open(file_name, 'w+', 'utf-8')
    writer = csv.writer(file_csv, delimiter=',', quoting=csv.QUOTE_MINIMAL)
    for data in datas:
        writer.writerow(data)
    print("write succ!!")
################ 璁扮偣鍑芥暟 ################

#浠庡垵濮嬬偣璁板綍鐨勭紪鐮佸櫒璺濈  
def distanceCallback(distance_msg):
    global distance_to_start,save_flag,change_receive,stop_point,point
    global x,y,flag,pub_flag,vel_pub,encoder_start_flag,stanley_controller
    distance_to_start = distance_msg.data
    print(flag,change_receive)
    # flag = 0 绗 涓€鍦堟柇璺 鍖       
    if flag==0:
        twist1 = Twist()
        print(x)
        #flag鍒囨崲鏃跺紑濮嬬紪鐮佸櫒绉 鍒 
        if encoder_start_flag==0:
            encoder.start_recording(distance_to_start)
            encoder_start_flag=1
        #鑾峰彇缂栫爜鍣ㄨ窛绂 
        encoder_length=encoder.get_current_distance(distance_to_start)
        print(encoder_length)
        if encoder_length<1.2:
            twist1.angular.z = 80
            twist1.linear.x = 1560
        elif encoder_length >=1.2 and abs(yaw-zero_yaw)<150:
            twist1.angular.z = 110
            twist1.linear.x = 1560
        else:
            flag=1
        vel_pub.publish(twist1)

    # flag = 1 绗 涓€鍦堥浄杈惧贰绾 
    if flag==1:
        #flag鍒囨崲鏃跺紑濮嬬紪鐮佸櫒绉 鍒 
        if encoder_start_flag==0:
            encoder.start_recording(distance_to_start)
            encoder_start_flag=1
        encoder_length=encoder.get_current_distance(distance_to_start)

        if encoder_length>8 and abs(yaw-zero_yaw) <= 10:
            time.sleep(0.2)
            flag=2
            encoder_start_flag=0
        twist = Twist()
        twist.angular.z = 80 + delta_degrees
        twist.linear.x = SPEED
        vel_pub.publish(twist)
            
    #flag = 2 绾㈢豢鐏 鍋滆溅3s        
    if flag == 2:
        rospy.loginfo("get_RedandGreen_first_info!")
        twist_stop = Twist()
        twist_stop.linear.x = 1500
        twist_stop.angular.z = 80
        vel_pub.publish(twist_stop)
        int8_1=Int8()
        int8_1.data = flag
        pub_flag.publish(flag)
        time.sleep(3)
        flag=3

    #flag = 3 绗 涓€鍦堢孩缁跨伅鍋滆溅鍚庣敤鐩撮亾鍐插埡
    if flag == 3:
        if encoder_start_flag==0:
            encoder.start_recording(distance_to_start)
            encoder_start_flag=1
        encoder_length=encoder.get_current_distance(distance_to_start)
        if x<-6.5:
            error_yaw = yaw-zero_yaw
            #鍋忕Щ閲忎紶閫掔粰PID鎺у埗鍣 
            twist = Twist()
            twist.angular.z = 80 +40*error - 1*error_yaw
            twist.linear.x = 1553
            vel_pub.publish(twist)
        elif x>=-6.8 and x<-0.8:  
            error_yaw = yaw-zero_yaw
            #鍋忕Щ閲忎紶閫掔粰PID鎺у埗鍣 
            twist = Twist()
            twist.angular.z = 80 +40*error - 1*error_yaw
            twist.linear.x = SPEED_STRAIGHT
            vel_pub.publish(twist)
        else:
            encoder_start_flag=0
            if save_flag==2:
                flag = 4
            else:
                flag = 6
                    
    # flag = 4 绗 浜屽湀鏂 璺 鍖哄 艰埅
    if flag == 4:
        stanley_controller.control_loop()
        if encoder_start_flag==0:
            encoder.start_recording(distance_to_start)
            encoder_start_flag=1
        encoder_length=encoder.get_current_distance(distance_to_start)
        if encoder_length >= 1.3 and abs(yaw-zero_yaw)>170:
            flag=5
            encoder_start_flag=0

    # flag = 5 绗 浜屽湀瀵艰埅
    if flag == 5:
        stanley_controller.control_loop()
        if abs(yaw-zero_yaw) <= 10:
            flag=6

# flag = 6 绾㈢豢鐏 鍋滆溅3s
    if flag == 6:
        encoder.start_recording(distance_to_start)
        rospy.loginfo("get_RedandGreen_second_info!")
        twist_stop = Twist()
        twist_stop.linear.x = 1500
        twist_stop.angular.z = 80
        vel_pub.publish(twist_stop)
        time.sleep(3) 
        flag = 7    

# flag = 7 鍋滆溅
    if flag == 7:
        print(x)
        if change_receive==0:#鍋淎
            if x < -5.2:
                twist = Twist()
                error_yaw = yaw-zero_yaw
                #鍋忕Щ閲忎紶閫掔粰PID鎺у埗鍣 
                twist.angular.z = 80 +65*error - 1*error_yaw
                twist.linear.x = 1565
                vel_pub.publish(twist)
            elif x >= -5.2 and x <= -4.3:
                twist = Twist()
                twist.linear.x = 1550
                twist.angular.z = 123
                vel_pub.publish(twist)
            else:
                flag=8
        else:#鍋淏
            if x < -5.2:
                twist = Twist()
                error_yaw = yaw-zero_yaw
                #鍋忕Щ閲忎紶閫掔粰PID鎺у埗鍣 
                twist.angular.z = 80 +65*error - 1*error_yaw
                twist.linear.x = 1569
                vel_pub.publish(twist)
            elif x >= -5.2 and x <= -4.3:
                twist = Twist()
                twist.linear.x = 1550
                twist.angular.z = 38
                vel_pub.publish(twist)
            else:
                flag=8
        

# flag = 8 鍋滆溅
    if flag == 8:
        print("Stop")
        twist_end = Twist()
        twist_end.linear.x = 1500
        twist_end.angular.z = 88 
        vel_pub.publish(twist_end)
        flag=9

#IMU 鍥炶皟鍑芥暟
def imu_callback(msg):
    global yaw
    if msg.orientation_covariance[0] < 0:
        return
    # 鍥涘厓鏁拌浆鎴愭 ф媺瑙 
    quaternion = [
        msg.orientation.x,
        msg.orientation.y,
        msg.orientation.z,
        msg.orientation.w
    ]
    (roll,pitch,yaw_rad) = euler_from_quaternion(quaternion)
    # 寮у害鎹㈢畻鎴愯 掑害
    roll = roll*180/math.pi
    pitch = pitch*180/math.pi
    yaw = yaw_rad*180/math.pi
    # 灏唝aw闄愬埗鍦╗-180, 180]鑼冨洿鍐 
    yaw0 = (yaw + 180) % 360 - 180

#閫熷害鍥炶皟鍑芥暟
def velocityCallback(vel_msg):
    global cur_vel
    cur_vel = vel_msg.data
################ 鍥炶皟鍑芥暟 ################

def filter_large_angle_changes(points, angle_threshold=75):
    filtered_points=points
    if len(filtered_points)>2:
        dx = filtered_points[-2][0] - filtered_points[-1][0]
        dy = filtered_points[-2][1] - filtered_points[-1][1]
        current_direction = np.degrees(np.arctan2(dy, dx))  # 鏂瑰悜瑙掕浆涓哄害鏁 
        dx = filtered_points[-3][0] - filtered_points[-2][0]
        dy = filtered_points[-3][1] - filtered_points[-2][1]
        prev_direction = np.degrees(np.arctan2(dy, dx))  # 鏂瑰悜瑙掕浆涓哄害鏁 
        angle_change = abs(current_direction - prev_direction)
        angle_change = min(angle_change, 360 - angle_change)  # 澶勭悊瑙掑害鐜 缁曢棶棰 
        # 濡傛灉鍙樺寲澶т簬闃堝€硷紝璺宠繃姝ょ偣
        if angle_change > angle_threshold:
            filtered_points.pop()
    return filtered_points

def find_A_or_B(point, angle_threshold=30):
    # 瀛樺偍淇濈暀鐨勭偣
    points=point.copy()
    filtered_points = [points[0]]  # 淇濈暀绗 涓€涓 鐐 
    prev_direction = None  # 鍒濆 嬫柟鍚戣  
    for j in range(1, len(points)):
        if abs(np.linalg.norm(points[j]-points[j-1]))<0.3:
            points.pop(j)
    for i in range(1, len(points)):
        # 璁＄畻褰撳墠鐐逛笌鍓嶄竴鐐圭殑鏂瑰悜瑙 
        dx = points[i][0] - filtered_points[-1][0]
        dy = points[i][1] - filtered_points[-1][1]
        current_direction = np.degrees(np.arctan2(dy, dx))  # 鏂瑰悜瑙掕浆涓哄害鏁 
        if prev_direction is not None:
            # 璁＄畻鏂瑰悜瑙掑樊鍊煎苟褰掍竴鍖栧埌 [0, 180]
            angle_change = abs(current_direction - prev_direction)
            angle_change = min(angle_change, 360 - angle_change)  # 澶勭悊瑙掑害鐜 缁曢棶棰 
            # 濡傛灉鍙樺寲澶т簬闃堝€硷紝璺宠繃姝ょ偣
            if angle_change > angle_threshold:
                return 1
        # 鏇存柊鏂瑰悜瑙掑拰娣诲姞褰撳墠鐐 
        prev_direction = current_direction
    return 0

#闆疯揪鍥炶皟鍑芥暟锛堝熀纭€鎵€鏈夊姛鑳藉疄鐜帮級
def laser_scan_callback(msg):
    global flag,pub_flag,mid_x,mid_y,delta_degrees,error,delta_degrees1,x_laser,stop_point
    int8_1=Int8()
    int8_1.data = flag
    pub_flag.publish(flag)
        # flag = 0 绗 涓€鍦堟柇璺 鍖       
    if flag==1 or flag==3 or flag==4 or flag==5 or flag==6 or flag==7:
        #浠嶭aserScan娑堟伅涓 鑾峰彇瑙掑害鍜岃窛绂绘暟鎹 
        angles = np.linspace(msg.angle_min, msg.angle_max, len(msg.ranges))
        ranges = np.array(msg.ranges)
        #杩囨护鎺夋棤鏁堢殑璺濈 绘暟鎹 锛堜緥濡傛棤绌峰ぇ琛ㄧず娌℃湁鍙嶅皠鐐癸級
        valid_indices = np.isfinite(ranges)
        angles = angles[valid_indices]
        ranges = ranges[valid_indices]
        #杩囨护璺濈 昏秴杩囬槇鍊肩殑鐐 
        within_distance_indices = ranges <= max_distance
        angles = angles[within_distance_indices]
        ranges = ranges[within_distance_indices]
        #杞 鎹㈣ 掑害鑼冨洿鍒癧-蟺, 蟺]锛岀劧鍚庣瓫閫夊墠鏂 150搴︾殑鏁版嵁
        angles = (angles + np.pi) % (2 * np.pi) - np.pi  # 灏嗚 掑害杞 鎹 涓篬-蟺, 蟺]鑼冨洿
        within_front_angle_indices = (angles >= front_angle_min) & (angles <= front_angle_max)
        angles = angles[within_front_angle_indices]
        ranges = ranges[within_front_angle_indices]
        #灏嗘瀬鍧愭爣杞 鎹 涓虹瑳鍗″皵鍧愭爣绯  (x, y)
        x1 = ranges * np.cos(angles)
        y1 = ranges * np.sin(angles)
        laser_points = np.vstack((x1, y1)).T
        #浣跨敤DBSCAN杩涜 岃仛绫 
        db = DBSCAN(eps=dbscan_eps, min_samples=dbscan_min_samples).fit(laser_points)
        labels = db.labels_
        #鑾峰彇鍞 涓€鐨勭皣鏍囩  
        unique_labels = set(labels)
        cluster_centers = []
        #宸﹀彸閿ユ《鐨勭偣
        left_cones = []
        right_cones = []
        cones = []
        for k in unique_labels:
            if k == -1:
                continue
            class_member_mask = (labels == k)
            xy = laser_points[class_member_mask]
            cluster_center = np.mean(xy, axis=0)
            cluster_centers.append((k, cluster_center))
            cones.append(cluster_center)
        left_cones,right_cones=allocate_cones(cones)

        # if flag==6:
        #     stop_point=find_A_or_B(right_cones)
        #     print("stop_point=",stop_point)

        left_cones_filted=filter_large_angle_changes(left_cones)
        right_cones_filted=filter_large_angle_changes(right_cones)
        if x_laser>-6.5:
            left_x_bezier, left_y_bezier = bezier_curve(left_cones_filted)
        else:
            left_x_bezier, left_y_bezier = bezier_curve(left_cones)
        right_x_bezier, right_y_bezier = bezier_curve(right_cones_filted)
        #璁＄畻涓 鐐规洸绾 
        mid_x, mid_y = midpoints_curve((left_x_bezier, left_y_bezier), (right_x_bezier, right_y_bezier))

        base_path = Path()
        base_path.header.frame_id = 'base_link'
        left_path = rospy.Publisher('/left_laser_path', Path, queue_size=1, latch=True)
        mid_path = rospy.Publisher('/mid_laser_path', Path, queue_size=1, latch=True)
        right_path = rospy.Publisher('/right_laser_path', Path, queue_size=1, latch=True)
        left_path_msg = Path()
        left_path_msg.header.frame_id = 'base_link'
        for x, y in left_cones:
            path_element = PoseStamped()
            path_element.pose.position.x = x
            path_element.pose.position.y = y
            left_path_msg.poses.append(path_element)
        left_path.publish(left_path_msg)
        right_path_msg = Path()
        right_path_msg.header.frame_id = 'base_link'
        for x, y in right_cones_filted:
            path_element = PoseStamped()
            path_element.pose.position.x = x
            path_element.pose.position.y = y
            right_path_msg.poses.append(path_element)
        right_path.publish(right_path_msg)
        mid_path_msg = Path()
        mid_path_msg.header.frame_id = 'base_link'
        for x, y in zip(mid_x, mid_y):
            path_element = PoseStamped()
            path_element.pose.position.x = x
            path_element.pose.position.y = y
            mid_path_msg.poses.append(path_element)
        mid_path.publish(mid_path_msg)
        #stanly鎺у埗鍣 
        follow_index = FOLLOW
        e = mid_y[int(follow_index)]
        yaw_path = get_yaw_from_path(mid_x, mid_y)
        theta_e = normalize_angle(yaw_path)
        #Stanley鎺у埗寰 
        v = cur_vel  
        if v <=0.1:
            v=0.1
        k_e = K_E
        #v = 1   # 鍋囪 鹃€熷害鎭掑畾涓  ~ m/s
        heng_e = np.arctan2(k_e * e, v)#v瓒婂皬锛岃 掕秺澶э紱k_e瓒婂ぇ锛岃 掕秺澶 
        delta = theta_e + heng_e
        #灏哾elta杞 鎹 涓鸿 掑害鍒讹紙搴︼級
        delta_degrees1 = np.degrees(delta)
        delta_degrees=bend_pid.positional(delta_degrees1)
        rospy.loginfo("%.2f",delta_degrees)

        segment_y = mid_y[9:90]  # 娉ㄦ剰Python鐨勭储寮曟槸浠 0寮€濮嬬殑锛岀  20涓 鍏冪礌瀵瑰簲绱㈠紩19
        length = len(segment_y)
        linear_weights = np.linspace(1.3,1, length)
        linear_weights /= linear_weights.sum()  # 褰掍竴鍖栨潈閲 
        error = np.sum(segment_y * linear_weights)

# ========================
#         涓诲惊鐜 
# ========================
if __name__ == '__main__':
    try:
        rospy.init_node('new_laser_go', anonymous=True)                       # 鍒濆 嬪寲鑺傜偣
        pub_flag =rospy.Publisher('/flag', Int8, queue_size=10)               # flag鍙戝竷
        vel_pub = rospy.Publisher('/car/vel', Twist, queue_size=10)           # 閫熷害鍙戝竷
        encoder=EncoderDistanceTracker()                                      # 缂栫爜鍣 
        time.sleep(0.1)                                                         # 绋冲畾鍒濆 嬪寲
        
        rospy.Subscriber("/imu_data",Imu,imu_callback,queue_size=10)          # imu鍥炶皟鍑芥暟
        rospy.Subscriber('/change', Int32, change_callback)                   # 鏍囧織浣嶅洖璋冨嚱鏁 
        rospy.Subscriber("/encoder_imu_odom", Odometry, odom_callback)        # 浜岀淮鍧愭爣鍥炶皟鍑芥暟
        rospy.Subscriber('/distance_traveled', Float64, distanceCallback)     # 缂栫爜鍣ㄥ洖璋冨嚱鏁 
        rospy.Subscriber('/nowa_vel', Float64, velocityCallback)
        #lasernode = LaserScanPublisher()
        time.sleep(1) 
        zero_yaw=yaw

        rospy.Publisher('/base_path', Path, queue_size=1, latch=True)

        time.sleep(0.1) 
        rospy.Subscriber('/scan', LaserScan, laser_scan_callback)             # 闆疯揪鍥炶皟鍑芥暟
        bend_pid=PID(bend_kp,bend_ki,bend_kd)                                 # 寮 閬 
        stanley_controller = StanleyController()
        
        time.sleep(0.1)                                                         # 绋冲畾鍒濆 嬪寲

        while not rospy.is_shutdown():
            if flag==3:
                if x>-6.8:
                    if save_flag==0:
                        save_flag=1
                        time.sleep(0.2)
                        control_points = point.copy()
                        print(control_points)
                        # 鐢熸垚璐濆 炲皵鏇茬嚎鎷熷悎璺 寰 
                        x_spline, y_spline = bezier_curve_fitting(control_points)
                        # 鏋勫缓璺 寰勬暟缁 
                        path = [(x, y) for x, y in zip(x_spline, y_spline)]
                        stanley_controller.set_path(path)
                        save_flag=2
                        pub_path = rospy.Publisher('/base_path', Path, queue_size=1, latch=True)
                        nav_msg = Path()
                        nav_msg.header.frame_id = 'odom'
                        for x2, y2 in control_points:
                            path_element = PoseStamped()
                            path_element.pose.position.x = x2
                            path_element.pose.position.y = y2
                            nav_msg.poses.append(path_element)
                        pub_path.publish(nav_msg)
            time.sleep(0.5)
            print("While call")

        rospy.spin()                                                          # ROS寰 鐜 绛夊緟

    except rospy.ROSInterruptException:
        pass
