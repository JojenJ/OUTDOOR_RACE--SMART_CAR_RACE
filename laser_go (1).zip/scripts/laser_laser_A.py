#!/usr/bin/env python3
# coding=utf-8

import rospy  # type: ignore
import numpy as np # type: ignore
from sensor_msgs.msg import LaserScan # type: ignore
from sklearn.cluster import DBSCAN # type: ignore
from geometry_msgs.msg import Twist,PoseStamped # type: ignore
from std_msgs.msg import Int32,Int8,Float64 # type: ignore
from sensor_msgs.msg import Imu # type: ignore
from tf.transformations import euler_from_quaternion # type: ignore
import math
import time
from math import factorial
import subprocess
import tf
from scipy.spatial import KDTree
from scipy.interpolate import splprep, splev
import csv, codecs
from nav_msgs.msg import Path,Odometry
import os

def execute_ros_command(command):
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()

################ 重要参数 ################
bend_kp=1
bend_ki=0
bend_kd=0

SPEED=1560        # 主速度
SPEED_STRAIGHT=1570   # 直道速度
K_E = 1.3
FOLLOW = 50
################ 重要参数 ################

# 模式切换标志位
# flag = 0 摄像头训线
# flag = 1 雷达巡线
# flag = 2 红绿灯停车3s
# flag = 3 直道加速
# flag = 4 雷达巡线
# flag = 6 红绿灯停车3s
# flag = 7 A点停车
# flag = 8 结束
flag = 0

################ 可调整参数 ################
# 设置激光雷达的最大检测距离（以米为单位）
max_distance = 3 # 只聚类离雷达3米以内的点

# 设置前方的角度范围（以弧度为单位）
front_angle_min = -95* np.pi / 180  # 车身前方最小角度（-95度）
front_angle_max = 95 * np.pi / 180   # 车身前方最大角度（95度）

# 设置DBSCAN聚类的参数
dbscan_eps = 0.14  # 邻域半径
dbscan_min_samples = 7  # 每个簇的最小样本数
################ 可调整参数 ################

################ 变量初始化 ################
encoder_start_flag=0
# 距离初始点的编码器距离
distance_to_start=0
cur_vel = 0
# 弧度换算成角度
roll  =0
pitch =0
yaw   =0
# 设置启动时的航向角为0度
zero_yaw=0
# 相对于起始点（0，0），车的二维坐标（x，y）
x = 0
y = 0
theta = 0
#雷达扫线
mid_x=[]
mid_y=[]
delta_degrees=0
error=0
################ 变量初始化 ################

kp = 1.05
ki = 0
kd = 0

cur_vel = 0

class PID:
    def __init__(self, kp, ki, kd, integral_limit=8.0):
        """
        初始化PID控制器。
        kp, ki, kd 是PID参数。
        integral_limit 是积分项的限制，以防止积分值过大。
        """
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral_limit = integral_limit
        self.error_out = 0.0
        self.last_error = 0.0
        self.integral = 0.0
        self.last_diff = 0.0


    def positional(self, error):
        """
        位置式PID控制器。
        根据误差计算控制输出。
        """
        self.integral += error
        # 积分限幅
        if self.integral > self.integral_limit:
            self.integral = self.integral_limit

        self.error_out = (self.kp * error) + (self.ki * self.integral) + (self.kd * (error - self.last_error))
        self.last_error = error
        return self.error_out

    def incremental(self, error):
        """
        增量式PID控制器。
        根据误差计算控制输出。
        """
        self.error_out = self.kp * (error - self.last_error) + self.ki * error + self.kd * ((error - self.last_error) - self.last_diff)
        self.last_diff = error - self.last_error
        self.last_error = error
        return self.error_out



class StanleyController:
    def __init__(self, k_e=1, wheel_base=1.0, lookahead_points=7):
        self.k_e = k_e
        self.wheel_base = wheel_base
        self.tf_listener = tf.TransformListener()
        self.rate = rospy.Rate(10)
        self.lookahead_points = lookahead_points  # 定义要查看的路径点数量
        self.path = None
        self.last_index = 0
        self.current_pose = PoseStamped()
        rospy.Subscriber('/encoder_imu_odom', Odometry, self.odom_callback)

    def odom_callback(self, msg):
        self.current_pose.pose.position.x = msg.pose.pose.position.x
        self.current_pose.pose.position.y = msg.pose.pose.position.y
        self.current_pose.pose.orientation = msg.pose.pose.orientation


    def set_path(self, path):
        """设置路径"""
        self.path = path

    def calculate_control(self, current_pose):
        """计算Stanley控制指令"""
        nearest_index, nearest_distance = self.get_nearest_point(current_pose)

        # 计算横向误差（cross-track error）
        # 计算路径方向向量
        dx = self.path[min(nearest_index+2,len(self.path))-1][0] - self.path[nearest_index][0]
        dy = self.path[min(nearest_index+2,len(self.path))-1][1] - self.path[nearest_index][1]

        # 计算车辆当前位置与路径最近点之间的向量
        ex = current_pose.pose.position.x - self.path[nearest_index][0]
        ey = current_pose.pose.position.y - self.path[nearest_index][1]

        # 计算叉积来判断左右方向
        cross_product = dx * ey - dy * ex

        # 根据叉积为横向误差赋予正负号
        if cross_product < 0:
            e = nearest_distance  # 在路径左侧
        else:
            e = -nearest_distance  # 在路径右侧


        # 计算航向误差（heading error）
        # 使用后面几个点来计算路径的目标方向
        if nearest_index + self.lookahead_points < len(self.path):
            target_index = nearest_index + self.lookahead_points
        else:
            target_index = len(self.path) - 1
            rospy.loginfo("arrived!!")
            pub_flag =rospy.Publisher('/change', Int8, queue_size=10)
            pub_flag.publish(5)
            
        #rospy.loginfo("当前进度：%2f/%2f.",target_index,len(self.path))
        yaw_path = self.get_yaw_from_path(nearest_index, target_index)
        yaw_current = self.get_yaw(current_pose.pose.orientation)
        theta_e = self.normalize_angle(yaw_path - yaw_current)

        # Stanley控制律
        v = cur_vel  
        if v == 0:
            v = 1
        #v = 1   # 假设速度恒定为 ~ m/s
        heng_e = np.arctan2(self.k_e * e, v)#v越小，角越大；k_e越大，角越大
        delta = theta_e + heng_e
        
        # 将delta转换为角度制（度）
        delta_degrees = np.degrees(delta)
        theta_e_degrees = np.degrees(theta_e)
        heng_e_degrees = np.degrees(heng_e)
        rospy.loginfo("theta_e is :%2f", theta_e_degrees)
        rospy.loginfo("heng_e is :%2f", heng_e_degrees)
        return delta_degrees

    def control_loop(self):
        global flag
        if flag == 4 or flag== 5:
            # 计算控制指令
            delta = self.calculate_control(self.current_pose)
            self.publish_control(delta)
            self.rate.sleep()


    def publish_control(self, delta):
        """发布控制指令"""
        global vel_pub
        cmd = Twist()
        cmd.linear.x = 1560  # 恒定速度
        angular_z = 80 + delta
        if angular_z <=0:
            angular_z = 0
        if angular_z >= 180:
            angular_z = 180
        cmd.angular.z = angular_z
        
        vel_pub.publish(cmd)

    def get_nearest_point(self, current_pose):
        """找到与当前车辆位置最近的路径点"""
        min_dist = float('inf')
        min_index = self.last_index  # 从上一次找到的点开始搜索
        search_range = 20  # 设置搜索范围，避免遍历整个路径
        for i in range(max(self.last_index-search_range,0), min(self.last_index + search_range, len(self.path))):
            point = self.path[i]
            dist = np.sqrt((point[0] - current_pose.pose.position.x)**2 +
                        (point[1] - current_pose.pose.position.y)**2)
            if dist < min_dist:
                min_dist = dist
                min_index = i
                if min_dist < 0.05:  # 如果距离小于某个阈值，则认为找到了最近点
                    #rospy.loginfo("最近点的x:%.2f,y:%.2f,序号:%2f。", point[0], point[1],i)
                    break
        rospy.loginfo("找到的最近点坐标:%2f,%2f.",self.path[self.last_index][0],self.path[self.last_index][1])
        self.last_index = min_index  # 记录当前找到的最近点的索引
        rospy.loginfo("当前点:x:%.2f,y:%.2f。", current_pose.pose.position.x, current_pose.pose.position.y)
        #rospy.loginfo("最近点的距离：%.2f,角度：%.2f。", min_dist, min_index) 
        return min_index, min_dist

    def get_yaw_from_path(self, start_index, target_index):
        """从路径段中获取目标方向的yaw"""
        dx = self.path[target_index][0] - self.path[start_index][0]
        dy = self.path[target_index][1] - self.path[start_index][1]
        return np.arctan2(dy, dx)

    def get_yaw(self, orientation):
        """从四元数中获取yaw（航向角）"""
        quaternion = (orientation.x, orientation.y, orientation.z, orientation.w)
        euler = tf.transformations.euler_from_quaternion(quaternion)
        return euler[2]

    def quaternion_to_orientation(self, quaternion):
        """将四元数转换为ROS中的Orientation类型"""
        orientation = PoseStamped().pose.orientation
        orientation.x = quaternion[0]
        orientation.y = quaternion[1]
        orientation.z = quaternion[2]
        orientation.w = quaternion[3]
        return orientation

    def normalize_angle(self, angle):
        """将角度归一化到[-π, π]范围"""
        if angle > np.pi:
            angle -= 2.0 * np.pi
        elif angle < -np.pi:
            angle += 2.0 * np.pi
        return angle

def read_points_from_csv(file_name):
    """从CSV文件中读取点位数据"""
    points = []
    base_path = Path()
    base_path.header.frame_id = 'odom'
    pub_path = rospy.Publisher('/base_path', Path, queue_size=1, latch=True)
    with open(file_name, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            x, y, z, w = map(float, row)
            points.append([x, y, z, w])
            path_element = PoseStamped()
            path_element.pose.position.x = x
            path_element.pose.position.y = y
            base_path.poses.append(path_element)
        pub_path.publish(base_path)
        rospy.loginfo("updated!")
        
    return points

def bezier_curve_fitting(points, num_points=100):
    """基于控制点进行贝塞尔曲线拟合，生成路径"""
    points = np.array(points)
    tck, u = splprep([points[:, 0], points[:, 1]], s=0)
    u_new = np.linspace(u.min(), u.max(), num_points)
    x_new, y_new = splev(u_new, tck, der=0)
    return x_new, y_new

def velocityCallback(vel_msg):
    global cur_vel
    cur_vel = vel_msg.data
    
def flagCallback(vel_msg):
    global flag
    flag = vel_msg.data

# 编码器类
class EncoderDistanceTracker:
    def __init__(self):
        self.start_distance = 0
        self.current_distance = 0

    def start_recording(self, current_encoder_value):
        """开始记录积分，不返回值"""
        self.start_distance = current_encoder_value

    def get_current_distance(self, current_encoder_value):
        """获取当前的积分距离"""
        self.current_distance = current_encoder_value - self.start_distance
        return self.current_distance

# PID类
class PID:
    def __init__(self, kp, ki, kd, integral_limit=8.0):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral_limit = integral_limit
        self.error_out = 0.0
        self.last_error = 0.0
        self.integral = 0.0
        self.last_diff = 0.0

    def positional(self, error):
        self.integral += error
        # 积分限幅
        if self.integral > self.integral_limit:
            self.integral = self.integral_limit

        self.error_out = (self.kp * error) + (self.ki * self.integral) + (self.kd * (error - self.last_error))
        self.last_error = error
        return self.error_out

    def incremental(self, error):
        self.error_out = self.kp * (error - self.last_error) + self.ki * error + self.kd * ((error - self.last_error) - self.last_diff)
        self.last_diff = error - self.last_error
        self.last_error = error
        return self.error_out

################ 主要算法 ################
#识别锥桶的算法函数
def allocate_cones(cones):
    """
    将锥桶分配到左右数组中。

    参数:
    cones (list): 锥桶的二维坐标列表

    返回:
    tuple: 左侧锥桶列表和右侧锥桶列表
    """
    cone1=cones[0].copy()
    cone2=cones[0].copy()
    cone1[0]=-0.1
    cone1[1]=0.7
    left_cones = [cone1] 
    cone2[0]=-0.1
    cone2[1]=-0.7
    right_cones = [cone2]

    # 获取剩余锥桶
    remaining_cones = set(range(len(cones))) - {i for i, cone in enumerate(cones) if np.array_equal(cone, left_cones[0]) or np.array_equal(cone, right_cones[0])}

    # 找到剩余锥桶
    for _ in range(5):
        if remaining_cones:
            # 找到离左侧锥桶最近的锥桶
            left_distances = np.array([np.linalg.norm(cones[i] - left_cones[-1]) for i in remaining_cones])
            left_nearest_idx = list(remaining_cones)[np.argmin(left_distances)]
            if np.linalg.norm(left_cones[len(left_cones)-1]-cones[left_nearest_idx])<=1.35:
                left_cones.append(cones[left_nearest_idx])
                remaining_cones.remove(left_nearest_idx)

        if remaining_cones:
            # 找到离右侧锥桶最近的锥桶
            right_distances = np.array([np.linalg.norm(cones[i] - right_cones[-1]) for i in remaining_cones])
            right_nearest_idx = list(remaining_cones)[np.argmin(right_distances)]
            if np.linalg.norm(right_cones[len(right_cones)-1]-cones[right_nearest_idx])<=1.35:
                right_cones.append(cones[right_nearest_idx])
                remaining_cones.remove(right_nearest_idx)
    return left_cones, right_cones

#指数加权算法 对最新数据变化响应较快，同时保留历史数据
def ewma(values, alpha):
    weighted_sum = 0
    weighted_values = []
    for i, v in enumerate(values):
        weighted_sum = alpha * v + (1 - alpha) * weighted_sum
        weighted_values.append(weighted_sum)
    return weighted_values[-1]

#贝塞尔曲线拟合函数调用
def binom(n, k):
    return factorial(n) // (factorial(k) * factorial(n - k))

#生成贝塞尔曲线
def bezier_curve(points, n_points=100):
    n = len(points) - 1
    t = np.linspace(0, 1, n_points)
    curve = np.zeros((n_points, 2))
    for i in range(n_points):
        for j in range(n + 1):
            # 手动计算组合数
            binom_coeff = binom(n, j)
            
            # 计算贝塞尔基函数的值
            basis = (t[i] ** j) * ((1 - t[i]) ** (n - j))
            
            # 叠加每个控制点对当前曲线上点的贡献
            curve[i] += binom_coeff * basis * points[j]
    return curve[:, 0], curve[:, 1]

#左右边线拟合出中线
def midpoints_curve(left_curve, right_curve):
    mid_x = (left_curve[0] + right_curve[0]) / 2
    mid_y = (left_curve[1] + right_curve[1]) / 2
    return mid_x, mid_y

def get_yaw_from_path(x,y):
    dx = x[50] - x[30]
    dy = y[50] - y[30]
    return np.arctan2(dy, dx)

def normalize_angle(angle):
    """将角度归一化到[-π, π]范围"""
    if angle > np.pi:
        angle -= 2.0 * np.pi
    elif angle < -np.pi:
        angle += 2.0 * np.pi
    return angle
################ 主要算法 ################

################ 回调函数 ################
#标志位转换回调函数
def change_callback(msg):
    global flag
    if msg.data == 2:
        flag = msg.data
    elif msg.data == 5:
        flag = msg.data
    elif msg.data == 6:
        flag = msg.data

################ 记点函数 ################
recording_distance = 0.4  # 设置记录点的距离阈值，单位为米
last_recorded_position = None  # 用于存储上一个记录点的位置
point = []
#laser_go   flag
flag_last = 0

def convert_to_pose_stamped(data):
    pose_stamped = PoseStamped()
    pose_stamped.header = data.header  # 保留时间戳和frame_id
    pose_stamped.pose = data.pose.pose  # 直接提取位姿
    return pose_stamped

def odom_callback(self, msg):
    self.current_pose.pose.position.x = msg.pose.pose.position.x
    self.current_pose.pose.position.y = msg.pose.pose.position.y
    self.current_pose.pose.orientation = msg.pose.pose.orientation
    
def distance_between_points(p1, p2):
    """计算两点之间的欧几里得距离"""
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

#车相对于起始点的坐标和航向角回调函数
def odom_callback(odom_msg):
    global flag,x,y,theta
    global last_recorded_position, point,flag_last
    x = odom_msg.pose.pose.position.x
    y = odom_msg.pose.pose.position.y
    theta = odom_msg.pose.pose.orientation.z

    # 使用 Odometry 消息中的 pose 数据
    current_position = (odom_msg.pose.pose.position.x, odom_msg.pose.pose.position.y)
    if flag ==2 and flag_last == 0:
        flag_last = 1
        point.append([current_position[0], current_position[1], odom_msg.pose.pose.orientation.z, odom_msg.pose.pose.orientation.w])

    if last_recorded_position is None:
        point.append([current_position[0], current_position[1], odom_msg.pose.pose.orientation.z, odom_msg.pose.pose.orientation.w])
        last_recorded_position = current_position
    else:
        distance = distance_between_points(current_position, last_recorded_position)
        if distance >= recording_distance:
            point.append([current_position[0], current_position[1], odom_msg.pose.pose.orientation.z, odom_msg.pose.pose.orientation.w])
            last_recorded_position = current_position
            rospy.loginfo("记录新点: %2f, %2f", current_position[0], current_position[1])

def data_write_csv(file_name, datas):
    file_csv = codecs.open(file_name, 'w+', 'utf-8')
    writer = csv.writer(file_csv, delimiter=',', quoting=csv.QUOTE_MINIMAL)
    for data in datas:
        writer.writerow(data)
    print("write succ!!")
################ 记点函数 ################

save_flag=0

#从初始点记录的编码器距离
def distanceCallback(distance_msg):
    global distance_to_start,save_flag
    global x,y,flag,pub_flag,vel_pub,encoder_start_flag,stanley_controller
    distance_to_start = distance_msg.data
    print(flag)
    # flag = 0 第一圈断路区      
    if flag==0:
        twist1 = Twist()
        print(x)
        #flag切换时开始编码器积分
        if encoder_start_flag==0:
            encoder.start_recording(distance_to_start)
            encoder_start_flag=1
        #获取编码器距离
        encoder_length=encoder.get_current_distance(distance_to_start)
        print(encoder_length)
        if encoder_length<1.3:
            twist1.angular.z = 80
            twist1.linear.x = 1555
        elif encoder_length >=1.3 and abs(yaw-zero_yaw)<150:
            twist1.angular.z = 107
            twist1.linear.x = 1555
        else:
            flag=1
        vel_pub.publish(twist1)

    # flag = 1 第一圈雷达巡线
    if flag==1:
        #flag切换时开始编码器积分
        if encoder_start_flag==0:
            encoder.start_recording(distance_to_start)
            encoder_start_flag=1
        encoder_length=encoder.get_current_distance(distance_to_start)
        if encoder_length>15 and abs(yaw-zero_yaw) <= 5:
            flag=2
            encoder_start_flag=0
        twist = Twist()
        twist.angular.z = 80 + delta_degrees
        twist.linear.x = SPEED
        vel_pub.publish(twist)
            
    #flag = 2 红绿灯停车3s        
    if flag == 2:
        rospy.loginfo("get_RedandGreen_first_info!")
        if save_flag==0:
            save_flag=1
            data_write_csv('/racecar/src/laser_go/scripts/points.csv', point)
        twist_stop = Twist()
        twist_stop.linear.x = 1500
        twist_stop.angular.z = 80
        vel_pub.publish(twist_stop)
        int8_1=Int8()
        int8_1.data = flag
        pub_flag.publish(flag)
        time.sleep(3)
        if save_flag==1 and save_flag!=2:
            control_points = read_points_from_csv('/racecar/src/laser_go/scripts/points.csv')
            print(control_points)
            save_flag=2
            # 生成贝塞尔曲线拟合路径
            x_spline, y_spline = bezier_curve_fitting(control_points)
            # 构建路径数组
            path = [(x, y) for x, y in zip(x_spline, y_spline)]
            stanley_controller.set_path(path)       
            flag = 3

    #flag = 3 第一圈红绿灯停车后用直道冲刺
    if flag == 3:
        if encoder_start_flag==0:
            encoder.start_recording(distance_to_start)
            encoder_start_flag=1
        encoder_length=encoder.get_current_distance(distance_to_start)
        if x<-0.8:
            error_yaw = yaw-zero_yaw
            #偏移量传递给PID控制器
            twist = Twist()
            twist.angular.z = 80 +40*error - 1*error_yaw
            twist.linear.x = SPEED_STRAIGHT
            vel_pub.publish(twist)
        else :
            encoder_start_flag=0
            flag = 4
                    
    # flag = 4 第二圈断路区daohang
    if flag == 4:
        stanley_controller.control_loop()
        if encoder_start_flag==0:
            encoder.start_recording(distance_to_start)
            encoder_start_flag=1
        encoder_length=encoder.get_current_distance(distance_to_start)
        if encoder_length >= 1.3 and abs(yaw-zero_yaw)>170:
            flag=5
            encoder_start_flag=0

    # flag = 5 第二圈daohang
    if flag == 5:
        #flag切换时开始编码器积分
        if encoder_start_flag==0:
            encoder.start_recording(distance_to_start)
            encoder_start_flag=1
        encoder_length=encoder.get_current_distance(distance_to_start)
        if encoder_length>10 and abs(yaw-zero_yaw) <= 5:
            flag=6
            encoder_start_flag=0
        twist = Twist()
        twist.angular.z = 80 + delta_degrees
        twist.linear.x = SPEED
        vel_pub.publish(twist)

# flag = 6 红绿灯停车3s
    if flag == 6:
        encoder.start_recording(distance_to_start)
        rospy.loginfo("get_RedandGreen_first_info!")
        twist_stop = Twist()
        twist_stop.linear.x = 1500
        twist_stop.angular.z = 80
        vel_pub.publish(twist_stop)
        time.sleep(3) 
        flag = 7    

# flag = 7 A点停车
    if flag == 7:
        print(x)
        if x < -4.7:
            twist = Twist()
            error_yaw = yaw-zero_yaw
            #偏移量传递给PID控制器
            twist.angular.z = 80 +40*error - 1*error_yaw
            twist.linear.x = 1567
            vel_pub.publish(twist)
        elif x >= -4.7 and x <= -4:
            twist = Twist()
            twist.angular.z = 123 # 要调
            twist.linear.x = 1550
            vel_pub.publish(twist)
        else:
            flag=8

# flag = 8 停车
    if flag == 8:
        print("Stop")
        twist_end = Twist()
        twist_end.linear.x = 1500
        twist_end.angular.z = 88 
        vel_pub.publish(twist_end)
        flag=9

#IMU 回调函数
def imu_callback(msg):
    global yaw
    if msg.orientation_covariance[0] < 0:
        return
    # 四元数转成欧拉角
    quaternion = [
        msg.orientation.x,
        msg.orientation.y,
        msg.orientation.z,
        msg.orientation.w
    ]
    (roll,pitch,yaw_rad) = euler_from_quaternion(quaternion)
    # 弧度换算成角度
    roll = roll*180/math.pi
    pitch = pitch*180/math.pi
    yaw = yaw_rad*180/math.pi
    # 将yaw限制在[-180, 180]范围内
    yaw0 = (yaw + 180) % 360 - 180

#速度回调函数
def velocityCallback(vel_msg):
    global cur_vel
    cur_vel = vel_msg.data
################ 回调函数 ################

#雷达回调函数（基础所有功能实现）
def laser_scan_callback(msg):
    global flag,pub_flag,mid_x,mid_y,delta_degrees,error
    int8_1=Int8()
    int8_1.data = flag
    pub_flag.publish(flag)
        # flag = 0 第一圈断路区      
    if flag==1 or flag==3 or flag==4 or flag==5 or flag==7:
        #从LaserScan消息中获取角度和距离数据
        angles = np.linspace(msg.angle_min, msg.angle_max, len(msg.ranges))
        ranges = np.array(msg.ranges)
        #过滤掉无效的距离数据（例如无穷大表示没有反射点）
        valid_indices = np.isfinite(ranges)
        angles = angles[valid_indices]
        ranges = ranges[valid_indices]
        #过滤距离超过阈值的点
        within_distance_indices = ranges <= max_distance
        angles = angles[within_distance_indices]
        ranges = ranges[within_distance_indices]
        #转换角度范围到[-π, π]，然后筛选前方150度的数据
        angles = (angles + np.pi) % (2 * np.pi) - np.pi  # 将角度转换为[-π, π]范围
        within_front_angle_indices = (angles >= front_angle_min) & (angles <= front_angle_max)
        angles = angles[within_front_angle_indices]
        ranges = ranges[within_front_angle_indices]
        #将极坐标转换为笛卡尔坐标系 (x, y)
        x1 = ranges * np.cos(angles)
        y1 = ranges * np.sin(angles)
        laser_points = np.vstack((x1, y1)).T
        #使用DBSCAN进行聚类
        db = DBSCAN(eps=dbscan_eps, min_samples=dbscan_min_samples).fit(laser_points)
        labels = db.labels_
        #获取唯一的簇标签
        unique_labels = set(labels)
        cluster_centers = []
        #左右锥桶的点
        left_cones = []
        right_cones = []
        cones = []
        for k in unique_labels:
            if k == -1:
                continue
            class_member_mask = (labels == k)
            xy = laser_points[class_member_mask]
            cluster_center = np.mean(xy, axis=0)
            cluster_centers.append((k, cluster_center))
            cones.append(cluster_center)
        left_cones,right_cones=allocate_cones(cones)
        left_x_bezier, left_y_bezier = bezier_curve(left_cones)
        right_x_bezier, right_y_bezier = bezier_curve(right_cones)
        #计算中点曲线
        mid_x, mid_y = midpoints_curve((left_x_bezier, left_y_bezier), (right_x_bezier, right_y_bezier))

#发布路径
        base_path = Path()
        base_path.header.frame_id = 'base_link'
        left_path = rospy.Publisher('/left_laser_path', Path, queue_size=1, latch=True)
        mid_path = rospy.Publisher('/mid_laser_path', Path, queue_size=1, latch=True)
        right_path = rospy.Publisher('/right_laser_path', Path, queue_size=1, latch=True)
        left_path_msg = Path()
        left_path_msg.header.frame_id = 'base_link'
        for x, y in zip(left_x_bezier, left_y_bezier):
            path_element = PoseStamped()
            path_element.pose.position.x = x
            path_element.pose.position.y = y
            left_path_msg.poses.append(path_element)
        left_path.publish(left_path_msg)
        right_path_msg = Path()
        right_path_msg.header.frame_id = 'base_link'
        for x, y in zip(right_x_bezier, right_y_bezier):
            path_element = PoseStamped()
            path_element.pose.position.x = x
            path_element.pose.position.y = y
            right_path_msg.poses.append(path_element)
        right_path.publish(right_path_msg)
        mid_path_msg = Path()
        mid_path_msg.header.frame_id = 'base_link'
        for x, y in zip(mid_x, mid_y):
            path_element = PoseStamped()
            path_element.pose.position.x = x
            path_element.pose.position.y = y
            mid_path_msg.poses.append(path_element)
        mid_path.publish(mid_path_msg)


        #stanly控制器
        follow_index = FOLLOW
        e = mid_y[int(follow_index)]
        yaw_path = get_yaw_from_path(mid_x, mid_y)
        theta_e = normalize_angle(yaw_path)
        #Stanley控制律
        v = cur_vel  
        if v <=0.1:
            v=0.1
        k_e = K_E
        #v = 1   # 假设速度恒定为 ~ m/s
        heng_e = np.arctan2(k_e * e, v)#v越小，角越大；k_e越大，角越大
        delta = theta_e + heng_e
        #将delta转换为角度制（度）
        delta_degrees = np.degrees(delta)
        delta_degrees=bend_pid.positional(delta_degrees)
        rospy.loginfo("%.2f",delta_degrees)

        segment_y = mid_y[9:90]  # 注意Python的索引是从0开始的，第20个元素对应索引19
        length = len(segment_y)
        linear_weights = np.linspace(1.3,1, length)
        linear_weights /= linear_weights.sum()  # 归一化权重
        error = np.sum(segment_y * linear_weights)

# ========================
#         主循环
# ========================
if __name__ == '__main__':
    try:
        rospy.init_node('new_laser_go', anonymous=True)                       # 初始化节点
        pub_flag =rospy.Publisher('/flag', Int8, queue_size=10)               # flag发布
        vel_pub = rospy.Publisher('/car/vel', Twist, queue_size=10)           # 速度发布
        encoder=EncoderDistanceTracker()                                      # 编码器
        time.sleep(0.1)                                                         # 稳定初始化

        rospy.Subscriber("/imu_data",Imu,imu_callback,queue_size=10)          # imu回调函数
        rospy.Subscriber('/change', Int32, change_callback)                   # 标志位回调函数
        rospy.Subscriber("/encoder_imu_odom", Odometry, odom_callback)        # 二维坐标回调函数
        rospy.Subscriber('/distance_traveled', Float64, distanceCallback)     # 编码器回调函数
        rospy.Subscriber('/nowa_vel', Float64, velocityCallback)
        time.sleep(1) 
        zero_yaw=yaw

        rospy.Publisher('/base_path', Path, queue_size=1, latch=True)

        time.sleep(0.1) 
        rospy.Subscriber('/scan', LaserScan, laser_scan_callback)             # 雷达回调函数
        bend_pid=PID(bend_kp,bend_ki,bend_kd)                                 # 弯道
        stanley_controller = StanleyController()
        
        time.sleep(0.1)                                                         # 稳定初始化

        rospy.spin()                                                          # ROS循环等待

    except rospy.ROSInterruptException:
        pass
