#!/usr/bin/env python3
# coding=utf-8

import rospy  # type: ignore
import numpy as np # type: ignore
from sensor_msgs.msg import LaserScan # type: ignore
from sklearn.cluster import DBSCAN # type: ignore
from geometry_msgs.msg import Twist,PoseStamped # type: ignore
from std_msgs.msg import Int32,Int8,Float64 # type: ignore
from sensor_msgs.msg import Imu # type: ignore
from tf.transformations import euler_from_quaternion # type: ignore
import math
import time
from math import factorial
from nav_msgs.msg import Odometry # type: ignore
import subprocess

from nav_msgs.msg import Path # type: ignore

def execute_ros_command(command):
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()

# 模式切换标志位
# flag = 0 摄像头训线 记点
# flag = 1 雷达巡线 记点
# flag = 2 红绿灯停车3s
# flag = 3 停车后用雷达直行固定距离后进行导航
# flag = 4 导航巡线
# flag = 5 红绿灯停车3s后 识别AB
# flag = 6 A点停车
# flag = 7 B点停车
# flag = 8 结束
flag = 0

#encoder_start_flag
encoder_start_flag=0
# 编码器变量
encoder_length=0
# 距离初始点的编码器距离
distance_to_start=0

# ==============================
#           可调整参数
# ==============================

# 设置激光雷达的最大检测距离（以米为单位）
max_distance = 3  # 只聚类离雷达2.5米以内的点

# 设置前方150度的角度范围（以弧度为单位）
front_angle_min = -85* np.pi / 180  # 车身前方最小角度（-75度）
front_angle_max = 85 * np.pi / 180   # 车身前方最大角度（75度）

# 设置DBSCAN聚类的参数
dbscan_eps = 0.14  # 邻域半径
dbscan_min_samples = 7  # 每个簇的最小样本数

# 同侧相邻锥桶的最大距离（以米为单位）
max_cone_distance = 1.3  # 1.4米

# 匹配左右锥桶时的距离范围（以米为单位）
min_match_distance = 1.35  # 最小距离
max_match_distance = 1.65  # 最大距离

# 需要补充或删减的锥桶数量
required_cone_count = 4  # 需要的锥桶数量

# PID参数
bend_kp=127
bend_ki=0
bend_kd=2.5

straight_kp=90
straight_ki=0
straight_kd=80

# 主速度
SPEED=1565

# 摄像头误差
error_cam=0

# 弧度换算成角度
roll  =0
pitch =0
yaw   =0

# 摄像头训线前后的角度差
forward_yaw=None
back_yaw   =0

min_distance1 = 7.50  # 设置第一次红绿灯最小距离 
max_distance1 = 9.04  # 设置第一次红绿灯最大距离
min_distance2 = 7.50  # 设置第二次红绿灯最小距离
max_distance2 = 9.04  # 设置第二次红绿灯最大距离
min_distance3 = 3.00  # 设置A点最小距离
max_distance3 = 3.35  # 设置A点最大距离
min_distance4 = 3.00  # 设置B点最小距离
max_distance4 = 3.35  # 设置B点最大距离

# 相对于起始点（0，0），车的二维坐标（x，y）
x = 0
y = 0
theta = 0

# ===========================================================================
#                                  编码器类
# 开始编码器积分：encoder.start_recording(distance_to_start)
# 结束编码器积分：encoder.stop_recording()
# 编码器积分距离：encoder_length=encoder.get_current_distance(distance_to_start)
class EncoderDistanceTracker:
    def __init__(self):
        self.start_distance = 0
        self.current_distance = 0

    def start_recording(self, current_encoder_value):
        """开始记录积分，不返回值"""
        self.start_distance = current_encoder_value

    def get_current_distance(self, current_encoder_value):
        """获取当前的积分距离"""
        self.current_distance = current_encoder_value - self.start_distance
        return self.current_distance
# ============================================================================= 

# =============================================================================
#                                 PID类
class PID:
    def __init__(self, kp, ki, kd, integral_limit=8.0):
        """
        初始化PID控制器。
        kp, ki, kd 是PID参数。
        integral_limit 是积分项的限制，以防止积分值过大。
        """
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral_limit = integral_limit
        self.error_out = 0.0
        self.last_error = 0.0
        self.integral = 0.0
        self.last_diff = 0.0

    def positional(self, error):
        """
        位置式PID控制器。
        根据误差计算控制输出。
        """
        self.integral += error
        # 积分限幅
        if self.integral > self.integral_limit:
            self.integral = self.integral_limit

        self.error_out = (self.kp * error) + (self.ki * self.integral) + (self.kd * (error - self.last_error))
        self.last_error = error
        return self.error_out

    def incremental(self, error):
        """
        增量式PID控制器。
        根据误差计算控制输出。
        """
        self.error_out = self.kp * (error - self.last_error) + self.ki * error + self.kd * ((error - self.last_error) - self.last_diff)
        self.last_diff = error - self.last_error
        self.last_error = error
        return self.error_out
# =================================================================================


# =================================================================================
#                               回调函数和算法实现
# =================================================================================


def Get_ang_error(ang,target_ang):
    error= abs(ang-target_ang)
    if error>180:
        error-=180
    return error

def Get_yaw_error(x,y,c_x,c_y,c_yaw):
    k=(c_y-y)/(c_x-x)
    ang=360*math.atan(k)/2/3.14159265
    # print(ang,c_yaw)

# ======================0
#    标志位转换回调函数
# ======================
def change_callback(msg):

    global flag
    if msg.data == 2:
        flag = msg.data
    elif msg.data == 5:
        flag = msg.data
    elif msg.data == 6:
        flag = msg.data
# ==============================
# 车相对于起始点的坐标和航向角回调函数
# ==============================
def odom_callback(odom_msg):

    global flag,length,yaw,x,y
    x = odom_msg.pose.pose.position.x
    y = odom_msg.pose.pose.position.y
    theta = odom_msg.pose.pose.orientation.z
    Get_yaw_error(0,0,x,y,yaw)
    # rospy.loginfo("x: %f, y: %f, theta: %f", odom_msg.pose.pose.position.x, odom_msg.pose.pose.position.y, odom_msg.pose.pose.orientation.z)

# ==============================
#     从初始点记录的编码器距离
# ==============================
def distanceCallback(distance_msg):
    global distance_to_start
    distance_to_start = distance_msg.data
    # rospy.loginfo("s= %f",distance_to_start)

# ====================
#     IMU 回调函数
# ====================
def imu_callback(msg):

    global yaw
    if msg.orientation_covariance[0] < 0:
        return
    # 四元数转成欧拉角
    quaternion = [
        msg.orientation.x,
        msg.orientation.y,
        msg.orientation.z,
        msg.orientation.w
    ]
    (roll,pitch,yaw) = euler_from_quaternion(quaternion)
    # 弧度换算成角度
    roll = roll*180/math.pi
    pitch = pitch*180/math.pi
    yaw = yaw*180/math.pi
    # rospy.loginfo("滚转= %.0f 俯仰= %.0f 朝向= %.0f", roll, pitch, yaw)

# =============================
#         摄像头回调函数
# =============================

error_cam=0

def Cam_scan_callback(msg):
    global error_cam
    error_cam=float(msg.data)


# =============================
#   雷达回调函数（基础所有功能实现）
# =============================      
def laser_scan_callback(msg):
    global x,y
    global flag,pub_flag,error_cam
    global vel_pub,encoder_start_flag

    global forward_length,back_length,length
    global distance_to_start

    int8_1=Int8()
    int8_1.data = flag
    pub_flag.publish(flag)

    # print(flag)

# flag = 8 停车
    if flag == 8:
        twist_end = Twist()
        twist_end.linear.x = 1490
        twist_end.angular.z = 88
        vel_pub.publish(twist_end)
        twist_end.linear.x = 1500
        twist_end.angular.z = 88 
        vel_pub.publish(twist_end)


# ========================
#         主循环
# ========================
if __name__ == '__main__':
    try:
        
        rospy.init_node('new_laser_go', anonymous=True)                       # 初始化节点
        pub_flag =rospy.Publisher('/flag', Int8, queue_size=10)               # flag发布
        vel_pub = rospy.Publisher('/car/vel', Twist, queue_size=10)           # 速度发布
        encoder=EncoderDistanceTracker()                                      # 编码器
        time.sleep(1)                                                         # 稳定初始化

        rospy.Subscriber("/imu_data",Imu,imu_callback,queue_size=10)          # imu回调函数
        rospy.Subscriber('/change', Int32, change_callback)                   # 标志位回调函数
        rospy.Subscriber('/cam_error', Int32, Cam_scan_callback)              # 摄像头巡线回调函数
        rospy.Subscriber("/encoder_imu_odom", Odometry, odom_callback)        # 二维坐标回调函数
        rospy.Subscriber('/distance_traveled', Float64, distanceCallback)     # 编码器回调函数

        rospy.Publisher('/base_path', Path, queue_size=1, latch=True)

        time.sleep(1) 
        rospy.Subscriber('/scan', LaserScan, laser_scan_callback)             # 雷达回调函数
        bend_pid=PID(bend_kp,bend_ki,bend_kd)                                 # 弯道
        straight_pid=PID(straight_kp,straight_ki,straight_kd)                 # 直到
        
        time.sleep(1)                                                         # 稳定初始化

        rospy.spin()                                                          # ROS循环等待

    except rospy.ROSInterruptException:
        pass
